var searchData=
[
  ['current_5fblock_5fenergy_5fmode_32',['current_block_energy_mode',['../sleep__routines_8c.html#a6543cf1ae0de352b82e80ec95be89727',1,'sleep_routines.c']]]
];
