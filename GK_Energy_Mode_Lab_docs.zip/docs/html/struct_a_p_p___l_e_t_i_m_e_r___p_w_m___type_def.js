var struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def =
[
    [ "active_period", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a1f35095c80d0db53cae171e4e89d947f", null ],
    [ "comp0_evt", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a6925635d915eac29de0937e724b4bd76", null ],
    [ "comp0_irq_enable", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#ad680c5351fec9189d3ad2dce4980ee2f", null ],
    [ "comp1_evt", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#ac6d36b52c08ecbf6cc9af9e37d8f186a", null ],
    [ "comp1_irq_enable", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a3b39f0f5b0ef484941e193598e1e2679", null ],
    [ "debugRun", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a95936f85c6ab1a7f43f02f15f172f1db", null ],
    [ "enable", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "out_pin_0_en", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a282598b3f0c3b0995d10b02906545832", null ],
    [ "out_pin_1_en", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#af699d0977554fdb7ace801a05b12655e", null ],
    [ "out_pin_route0", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#aa70bae1e59a3f0a1d2ea24fbe2fde697", null ],
    [ "out_pin_route1", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#ad2914f57ad42a0f261934757471ef343", null ],
    [ "period", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#ae08ac1ff9a62c213c5768ca3a538e546", null ],
    [ "uf_evt", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a82c096156654e7b45a5d450f5f28c031", null ],
    [ "uf_irq_enable", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#af104f924dc7950be2f072f3f923d636a", null ]
];